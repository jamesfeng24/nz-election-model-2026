"""Regression tests for review findings: transition density, fit persistence, fingerprints, electorates."""
import numpy as np
import jax.numpy as jnp
import pytest
from scipy import stats

import pollofpolls.model  # noqa: F401
from pollofpolls.cache import fingerprint
from pollofpolls.forecast.simulate import simulate_electorates
from pollofpolls.model.fit import FitResult, _diagnostics
from pollofpolls.model.numpyro_model import anchor_transition_logprob


def test_anchor_transition_density_matches_scipy():
    rng = np.random.default_rng(0)
    L = np.linalg.cholesky(np.array([[0.04, 0.01], [0.01, 0.09]]))
    anchors = rng.normal(size=(3, 2))
    V = np.cumsum(np.r_[0.0, rng.uniform(0.5, 2.0, size=29)])
    t = (0, 12, 29)
    got = float(anchor_transition_logprob(jnp.asarray(anchors), jnp.asarray(V), t, jnp.asarray(L)))
    want = sum(stats.multivariate_normal(np.zeros(2), (V[b] - V[a]) * L @ L.T).logpdf(anchors[i + 1] - anchors[i])
               for i, (a, b) in enumerate(zip(t[:-1], t[1:])))
    assert abs(got - want) < 1e-6


def test_fit_result_roundtrip_without_arviz(tmp_path):
    rng = np.random.default_rng(1)
    hyper = {"sigma": rng.normal(1, 0.1, size=(2, 100, 3)), "kappa": rng.normal(2, 0.1, size=(2, 100))}
    diag = _diagnostics(hyper, 0, 1.0, np.full((2, 100), 7))
    assert 0.9 < diag["max_rhat"] < 1.1 and diag["min_ess_bulk"] > 50 and diag["n_params_summarised"] == 4
    pi = rng.dirichlet(np.ones(4), size=(20, 5))
    fr = FitResult("x", 2026, ["National", "Labour", "Green", "Other"], [f"w{i}" for i in range(5)], pi.mean(0),
                   np.zeros((5, 4, 5)), pi, pi[:, 2], pi[:, 4], np.zeros((20, 3)), 2, 4, diag, hyper)
    fr.save(tmp_path / "fit")
    back = FitResult.load(tmp_path / "fit")
    assert set(back.hyper) == {"sigma", "kappa"} and np.allclose(back.hyper["sigma"], hyper["sigma"])
    assert back.diagnostics == diag


def test_fingerprint_ignores_bytecode(tmp_path):
    pkg = tmp_path / "model"
    pkg.mkdir()
    (pkg / "a.py").write_text("x = 1\n")
    before = fingerprint([pkg])
    (pkg / "__pycache__").mkdir()
    (pkg / "__pycache__" / "a.cpython-313.pyc").write_bytes(b"\x00\x01")
    assert fingerprint([pkg]) == before
    (pkg / "a.py").write_text("x = 2\n")
    assert fingerprint([pkg]) != before


@pytest.mark.parametrize("group_sd", [0.0, 0.8])
def test_electorate_marginals_match_config_at_reference_share(group_sd):
    parties = ["National", "Te Pāti Māori", "Other"]
    cfg = [{"electorate": "Te Tai Tonga", "party": "Te Pāti Māori", "p": 0.35, "at_share": 0.03, "slope": 0.4,
            "independent_p": 0.35}]
    S = 200_000
    pi = np.tile([0.5, 0.03, 0.47], (S, 1))
    el, ind = simulate_electorates(pi, parties, cfg, np.random.default_rng(2), group_sd=group_sd)
    assert abs(el[:, 1].mean() - 0.35) < 0.005
    assert abs(ind.mean() - 0.35) < 0.005
    assert not np.any((el[:, 1] > 0) & (ind > 0))          # mutually exclusive
    # when the party does better, its chance rises and the independent's falls
    el2, ind2 = simulate_electorates(np.tile([0.5, 0.05, 0.45], (S, 1)), parties, cfg,
                                    np.random.default_rng(3), group_sd=group_sd)
    assert el2[:, 1].mean() > 0.5 and ind2.mean() < 0.35


@pytest.mark.parametrize("p, independent_p", [(0.90, 0.05), (0.10, 0.80), (0.0, 1.0), (1.0, 0.0)])
def test_grouped_electorate_marginals_away_from_half(p, independent_p):
    cfg = [{"electorate": "Test seat", "party": "ACT", "p": p, "at_share": 0.09,
            "independent_p": independent_p}]
    pi = np.tile([0.5, 0.09, 0.41], (200_000, 1))
    el, ind = simulate_electorates(pi, ["National", "ACT", "Other"], cfg,
                                   np.random.default_rng(2), group_sd=0.8)
    assert abs(el[:, 1].mean() - p) < 0.005
    assert abs(ind.mean() - independent_p) < 0.005
    assert not np.any((el[:, 1] > 0) & (ind > 0))


# ---------------------------------------------------------------------------------- second review round
class _Resp:
    def __init__(self, status, text="", headers=None, url=""):
        self.status_code, self.text, self.headers, self.url = status, text, headers or {}, url

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(self.status_code)


def test_fetch_only_reuses_validators_for_the_same_article(tmp_path, monkeypatch):
    from pollofpolls.data import wikipedia
    sent = []

    def fake_get(url, headers, timeout):
        sent.append((url, dict(headers)))
        conditional = "If-None-Match" in headers or "If-Modified-Since" in headers
        if conditional and url.endswith("2026_New_Zealand_general_election"):
            return _Resp(304)
        return _Resp(200, f"<html>{url}</html>", {"Last-Modified": "Mon, 01 Jan 2026 00:00:00 GMT"}, url)

    monkeypatch.setattr(wikipedia.requests, "get", fake_get)
    wikipedia.fetch_page(2026, tmp_path)                                   # first download
    wikipedia.fetch_page(2026, tmp_path)                                   # same article: conditional, 304
    assert "If-Modified-Since" in sent[1][1]
    wikipedia.fetch_page(2026, tmp_path, page="Opinion polling for the next New Zealand general election")
    assert "If-Modified-Since" not in sent[2][1]                           # new article: no stale validators
    assert "next_New_Zealand" in (tmp_path / "2026.html").read_text()      # and its HTML replaced the old one


def test_polling_pages_stop_at_the_forecast_election(root):
    from pollofpolls.config import Config
    cfg = Config(root)
    cfg.elections_cfg["elections"].append({"year": 2029, "date": "2029-10-01", "pm_party": "National"})
    assert [y for y, _ in cfg.polling_pages] == [2011, 2014, 2017, 2020, 2023, 2026]
    assert max(e.year for e in cfg.window_elections) == 2026


def test_backtest_blocs_come_from_config(root):
    from pollofpolls.config import Config
    from pollofpolls.eval.backtest import blocs_for
    cfg = Config(root)
    assert blocs_for(cfg, 2023) == (["National", "ACT"], ["Labour", "Green", "Te Pāti Māori"])
    assert blocs_for(cfg, 2029) == (["National", "ACT"], ["Labour", "Green"])      # default


def test_balance_of_power_outcomes_are_exclusive():
    from pollofpolls.forecast.coalitions import balance_of_power
    parties = ["National", "Labour", "Green", "ACT", "NZ First", "TOP", "Other"]
    # House of 120, majority 61. Right = National + ACT.
    seats = np.array([
        [55, 30, 10, 8, 10, 7, 0],   # right 63: alone
        [48, 35, 10, 8, 12, 7, 0],   # right 56: NZ First (68) or TOP (63) each enough
        [50, 35, 12, 6, 12, 5, 0],   # right 56: NZ First (68) or TOP (61) each enough
        [45, 40, 13, 8, 7, 7, 0],    # right 53: neither alone (60, 60), both 67
        [40, 45, 15, 6, 7, 7, 0],    # right 46: short even with both (60)
    ])
    total = np.full(len(seats), 120)
    rows = balance_of_power(seats, parties, total, {"Right bloc": ["National", "ACT"]}, ["NZ First", "TOP"])
    r = rows[0]
    assert r["p_alone"] == 0.2 and r["p_needs_several"] == 0.2 and r["p_short"] == 0.2
    assert r["p_needs_all"] == 0.2                          # with two pivots, needing several is needing both
    assert r["p_any_one"] == 0.4 and r["p_with"]["NZ First"] == 0.4 and r["p_with"]["TOP"] == 0.4
    assert abs(r["p_alone"] + r["p_any_one"] + r["p_needs_several"] + r["p_short"] - 1) < 1e-12


def test_balance_of_power_does_not_call_every_pivot_necessary():
    """Three pivots with 8, 6 and 0 seats: the first two together are enough, so the third is not needed."""
    from pollofpolls.forecast.coalitions import balance_of_power
    parties = ["National", "ACT", "NZ First", "TOP", "Opportunity", "Labour", "Other"]
    seats = np.array([[45, 5, 8, 6, 0, 56, 0]])
    rows = balance_of_power(seats, parties, np.array([120]), {"Right bloc": ["National", "ACT"]},
                            ["NZ First", "TOP", "Opportunity"])
    r = rows[0]
    assert r["p_alone"] == 0 and r["p_any_one"] == 0 and r["p_short"] == 0
    assert r["p_needs_several"] == 1 and r["p_needs_all"] == 0


def test_small_and_untested_parties_get_a_wider_election_day_error():
    """Measured 2011-2023: parties polling under 8% missed their result by ~21% of their own support, against
    ~8% for larger parties, so their election-day error scale is multiplied."""
    from pollofpolls.prep.marshal import party_error_scale
    parties = ["National", "Green", "TOP", "New Party", "Other"]
    recent = np.array([0.29, 0.11, 0.068, 0.12, 0.03])      # support in the last polls before the cutoff
    best_past = np.array([0.44, 0.11, 0.022, 0.0, 0.03])    # best result at a completed election
    priors = {"minor_party_share": 0.08, "minor_party_factor": 2.5}
    got = party_error_scale(parties, recent, best_past, priors)
    assert list(got) == [1.0, 1.0, 2.5, 2.5, 1.0]           # small, and untested although polling 12%
    assert list(party_error_scale(parties, recent, best_past, {})) == [1.0] * 5   # off unless configured


def test_industry_error_keeps_its_scale_and_gains_tails():
    """The election-day polling error is Student-t: same standard deviation, far more room for a bad miss."""
    import numpyro

    from pollofpolls.model.numpyro_model import industry_raw
    with numpyro.handlers.seed(rng_seed=0):
        normal = np.asarray(industry_raw("normal", None, (40000,)))
        heavy = np.asarray(industry_raw("heavy", 4.0, (40000,)))
    assert abs(normal.std() - 1.0) < 0.05 and abs(heavy.std() - 1.0) < 0.2
    assert (np.abs(heavy) > 3).mean() > 3 * (np.abs(normal) > 3).mean()


def test_a_party_wins_or_loses_its_electorates_together():
    """Te Pāti Māori held no Māori electorate in 2017 and six in 2023: the seats are not independent coins."""
    from pollofpolls.forecast.simulate import simulate_electorates
    parties = ["National", "Te Pāti Māori", "Other"]
    cfg = [{"electorate": f"seat {i}", "party": "Te Pāti Māori", "p": 0.6, "at_share": 0.03, "slope": 0.0}
           for i in range(7)]
    pi = np.tile([0.40, 0.03, 0.57], (40000, 1))
    k = parties.index("Te Pāti Māori")
    alone = simulate_electorates(pi, parties, cfg, np.random.default_rng(0))[0][:, k]
    together = simulate_electorates(pi, parties, cfg, np.random.default_rng(0), group_sd=0.8)[0][:, k]
    assert abs(alone.mean() - together.mean()) < 0.25       # the same seats on average
    assert together.std() > 1.25 * alone.std()              # but a wider range
    assert (together == 0).mean() > 3 * (alone == 0).mean() # losing every seat is no longer near-impossible


def test_backtest_cases_are_rescored_when_the_blocs_change(tmp_path, monkeypatch):
    import json
    from types import SimpleNamespace

    import pytest

    from pollofpolls.eval import backtest as bt
    parties = ["National", "Labour", "Green", "ACT", "NZ First", "Other"]
    outcome = {"National": 0.38, "Labour": 0.32, "Green": 0.07, "ACT": 0.01, "NZ First": 0.08, "Other": 0.14}
    electorates = {2017: {"National": 41, "Labour": 29, "ACT": 1}}
    record = {"target": 2017, "horizon_weeks": 4, "variant": "base", "parties": parties, "outcome": outcome,
              "blocs": {"right": ["National", "ACT"], "left": ["Labour", "Green"]},
              "p_right_bloc_ahead": 0.9, "right_bloc_ahead": True, "brier_bloc": 0.01}
    new = {"right": ["National", "ACT"], "left": ["Labour", "Green", "NZ First"]}
    cfg = SimpleNamespace(model_cfg={"backtest": {"blocs": {2017: new}}})
    (tmp_path / "cases").mkdir()
    (tmp_path / "fits").mkdir()
    # unchanged blocs: the cached scores stand and nothing is read
    same = SimpleNamespace(model_cfg={"backtest": {"blocs": {2017: record["blocs"]}}})
    assert bt.rescore_blocs(same, tmp_path, record, electorates) is record
    # changed blocs without a cached fit: refuse rather than mix two events
    with pytest.raises(RuntimeError, match="base_2017_h4"):
        bt.rescore_blocs(cfg, tmp_path, record, electorates)
    # changed blocs with the fit: rescored from its draws with the new event, and the case file updated
    draws = np.tile([outcome[p] for p in parties], (50, 1))
    (tmp_path / "fits" / "base_2017_h4.npz").write_bytes(b"")
    monkeypatch.setattr(bt.FitResult, "load", classmethod(lambda cls, prefix: SimpleNamespace(pi_target=draws)))
    got = bt.rescore_blocs(cfg, tmp_path, record, electorates)
    want_p, want_actual = bt.bloc_probability(draws, parties, (new["right"], new["left"]), electorates[2017],
                                              np.array([outcome[p] for p in parties]))
    assert got["blocs"] == new and got["right_bloc_ahead"] is want_actual is False
    assert got["p_right_bloc_ahead"] == want_p and got["brier_bloc"] == bt.brier(want_p, want_actual)
    assert json.loads((tmp_path / "cases" / "base_2017_h4.json").read_text())["blocs"] == new
