"""Turn election-day vote-share draws into seat and coalition simulations."""

from __future__ import annotations

from functools import lru_cache

import numpy as np
from scipy import optimize, special, stats

from .seats import allocate_seats_matrix


@lru_cache(maxsize=128)
def _electorate_intercept(p: float, group_sd: float) -> float:
    """Logit intercept whose win probability averages to p over the shared normal shift."""
    base = float(special.logit(p))
    if group_sd <= 0 or not np.isfinite(base):
        return base                                  # includes certain wins and losses
    # Gauss-Hermite quadrature integrates over the group effect, independently of the simulated draws.
    nodes, weights = special.roots_hermitenorm(64)
    shifts = group_sd * nodes
    weights /= weights.sum()
    return float(optimize.brentq(lambda a: weights @ special.expit(a + shifts) - p,
                                 base - shifts[-1], base + shifts[-1]))


def simulate_electorates(pi: np.ndarray, parties: list[str], electorate_cfg: list[dict],
                         rng: np.random.Generator, group_sd: float = 0.0) -> tuple[np.ndarray, np.ndarray]:
    """Draw electorate wins for the configured seats. Returns (electorates (S,K), independent_seats (S,)).

    ``group_sd`` is the standard deviation of a shared logit shift applied to every electorate of a party
    (its `group`, the party name unless one is configured). It makes a party win or lose its electorates
    together, as they have historically, instead of each seat being an independent coin. Each intercept is
    calibrated so the marginal win probability at ``at_share`` still equals the configured ``p``.
    """
    S, K = pi.shape
    idx = {p: i for i, p in enumerate(parties)}
    electorates = np.zeros((S, K), dtype=int)
    independents = np.zeros(S, dtype=int)
    groups = {e.get("group", e["party"]) for e in electorate_cfg}
    shift = {g: (rng.normal(0.0, group_sd, size=S) if group_sd > 0 else np.zeros(S)) for g in sorted(groups)}
    for e in electorate_cfg:
        party = e["party"]
        if party not in idx:
            continue
        k = idx[party]
        p_ref, ind_ref = float(e["p"]), float(e.get("independent_p", 0.0))
        if p_ref + ind_ref > 1.0 + 1e-9:
            raise ValueError(f"{e['electorate']}: p + independent_p exceeds 1")
        # three mutually exclusive outcomes: the party, an independent, or anyone else. At the reference vote
        # share they have exactly the configured probabilities; as the party's vote moves, its chance moves
        # on the logit scale and the independent keeps the same share of the remaining probability.
        p_party = special.expit(_electorate_intercept(p_ref, group_sd) + shift[e.get("group", e["party"])]
                               + e.get("slope", 0.0) * 100.0 * (pi[:, k] - e.get("at_share", pi[:, k].mean())))
        p_ind = ind_ref * (1.0 - p_party) / (1.0 - p_ref) if ind_ref > 0 else np.zeros(S)
        u = rng.uniform(size=S)
        party_win = u < p_party
        ind_win = (~party_win) & (u < p_party + p_ind)
        electorates[party_win, k] += 1
        independents[ind_win] += 1
    return electorates, independents


def simulate_seats(pi: np.ndarray, parties: list[str], electorate_cfg: list[dict], n_sims: int,
                   rng: np.random.Generator, other_name: str = "Other", group_sd: float = 0.0) -> dict:
    """Seat simulation for election-day share draws ``pi`` (S, K). Returns arrays keyed by name."""
    S = pi.shape[0]
    take = rng.choice(S, size=min(n_sims, S), replace=n_sims > S) if n_sims != S else np.arange(S)
    pi = pi[take]
    votes = np.clip(pi, 0.0, None)
    if other_name in parties:
        votes[:, parties.index(other_name)] = 0.0   # "Other" is many parties, none of which qualifies
    electorates, independents = simulate_electorates(pi, parties, electorate_cfg, rng, group_sd)
    seats = allocate_seats_matrix(votes, electorates, independent_seats=independents)
    total = seats.sum(1) + independents
    return {"pi": pi, "seats": seats, "electorates": electorates, "independents": independents, "total": total}


def apply_fundamentals(pi: np.ndarray, pm_idx: int, prev_share: float, prior: dict,
                       rng: np.random.Generator) -> tuple[np.ndarray, float]:
    """Importance-resample election-day draws under the Student-t prior on the PM party's swing."""
    swing = pi[:, pm_idx] - prev_share
    logw = stats.t.logpdf(swing, df=prior["df"], loc=prior["mean"], scale=prior["sd"])
    w = np.exp(logw - logw.max())
    w /= w.sum()
    ess = 1.0 / np.sum(w ** 2)
    take = rng.choice(len(pi), size=len(pi), replace=True, p=w)
    return pi[take], float(ess)
